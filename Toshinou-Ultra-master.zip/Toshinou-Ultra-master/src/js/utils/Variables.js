class Variables {
	static get assetCreateX() {
		return "_-n3J";
	}
	
	static get assetCreateY() {
		return "_-T4i";
	}
	
	static get boxType() {
		return "_-O3e";
	}
	
	static get gateId() {
		return "_-i2R";
	}
	
	static get gateType() {
		return "_-M1K";
	}
	
	static get attackerId() {
		return "_-PK";
	}
	
	static get heroAttackedId() {
		return "_-92S";
	}
	
	static get attackHp() {
		return "_-G37";
	}
	
	static get attackShd() {
		return "_-X4V";
	}
	
	static get heroInitMaxHp() {
		return "_-937";
	}
	
	static get heroInitMaxShd() {
		return "_-G2p";
	}
	
	static get heroInitHp() {
		return "_-gi";
	}
	
	static get heroPetId() {
		return "_-a3c";
	}
	
	static get hpUpdateMaxHp() {
		return "_-71d";
	}
	
	static get hpUpdateHp() {
		return "_-p4e";
	}
	
	static get heroUpdateShd() {
		return "_-31q";
	}
	
	static get resource() {
		return "_-aE";
	}
	
	static get attackerId() {
		return "_-PK";
	}
	
	static get attackedId() {
		return "_-M3O";
	}
	
	static get clanDiplomacy() {
		return "_-Q3n";
	}
	
	static get shipDestroyedId() {
		return "_-D3e";
	}
	
	static get moveDuration() {
		return "_-N13";
	}
	
	static get selectMaxHp() {
		return "_-71d";
	}
	
	static get selectMaxShd() {
		return "_-G2p";
	}
	
	static get selectHp() {
		return "_-p4e";
	}
	
	static get resourceType() {
		return "_-h4k";
	}

	static get battlestationClanDiplomacy() {
		return "_-h27";
	}
}
