class Map {
   constructor(mapId,portals){
     this.mapId=mapId;
     this.portals=portals;
   }
}